Compile with TeX Live 2024 or equivalent:
  latexmk -pdf -interaction=nonstopmode -halt-on-error preliminary_report.tex

All figures and facts needed for compilation are included. Supporting tables are measured outputs; the full campaign contains their generating scripts, raw labels, lineage and validation receipts. This source bundle contains no new DFT results.
