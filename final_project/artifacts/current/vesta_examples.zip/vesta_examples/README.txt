Three existing, novel, low-tail CVAE mask lineages for VESTA

Open any .cif or .vasp file. Both formats contain the same geometry. CIFs use
P1 and explicit atoms: no symmetry expansion, average occupancies or ghost Li.
The atom-map CSVs map file rows to the original 192-atom parent slots.

sample_01_Li12: 25% lithiation; UMA standard CVAE, exact-count Bernoulli draw.
sample_02_Li24: 50% lithiation; UMA beta=0.1 CVAE, exact-count Bernoulli draw.
sample_03_Li36: 75% lithiation; MACE CVAE, top-count decoding.

Each folder has four versions of exactly the same ancestral vacancy mask:
01_vacancy_only: Mask CVAE output, Li deleted at pristine coordinates.
02_geometry_CVAE_unrelaxed: First prior draw from the separate UMA-trained
   displacement CVAE, applied to that mask; no subsequent minimization.
03_UMA_relaxed_from_vacancy: Existing fixed-cell UMA/FIRE endpoint from 01.
04_UMA_relaxed_from_geometry_CVAE: Existing fixed-cell UMA/FIRE endpoint from 02.

All optimized endpoints meet maximum atomic force <0.05 eV/Angstrom. The cell
was fixed, so stress need not be small. They are MLIP local minima to this
provisional force tolerance; they are not DFT-optimized or proven ground states.
No new MLIP evaluation or optimization was performed for this export.

Selection: one energy-conditioned CVAE lineage per Li count 12/24/36, chosen
from the existing 32-mask matched-relaxation diagnostic because all four
versions already existed and the DELETION geometry passes UMA's frozen
composition-specific training q20. This is an illustrative, favorable subset,
not a new performance test or the three lowest-energy configurations overall.
The full per-teacher pass/fail values and source checkpoint hashes are in
manifest.json; all measured version energies/forces are in energies_and_forces.csv.

The low-tail label applies to the deletion geometry and its deletion-energy
reference distribution. It must not be reinterpreted as a relaxed-energy
percentile. Compare absolute energies only at equal composition and teacher.
The symmetry-orbit key and evaluated-orientation vacancy mask can differ;
the original evaluated orientation is preserved, so force/coordinate rows match.

All 3 masks are distinct under the retained 192 parent permutations and absent
from the entire original 21,294-mask main catalog. Different Li counts are
necessarily different orbits. A pristine Li48 reference is included separately.
VESTA bond cutoffs affect display only. Visual plausibility and the force gate
do not establish DFT accuracy or thermal/phase stability.
